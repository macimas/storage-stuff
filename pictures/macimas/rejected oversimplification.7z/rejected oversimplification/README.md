macimas profile pictures but oversimplified.
decided to not to continue it, however i still have the respective pfps in socials i haven't used much as of january 23, 2022
