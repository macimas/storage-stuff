i will switch to EndeavourOS as my main distro soon
